I'm interested in applying data science in the area of augmented/virtual reality. (I'm primarily interested in content and market analysis. But, this data may be hard to find.) 

1. Now, my top pick is Kaggle's Painter by Numbers challenge.
Interesting project. I am a painter; so, my knowlege of painting technique should help.

2. Kaggle's Facial Keypoint Detection challenge

3. Kaggle's Digit Recognizer challenge

3. Sentiment comparison of Oculus Rigt and HTC Vibe. Data from scraping the web.

<br>

**VR/AR market**

* Platforms
	* data
		* Twitter data
		* Web crawl
		* Facebook
		* Blogs
	* Questions
		* Who
			* Who are early adopters?
			* Who will lead adoption?
		* Predicting rate of adoption
			* Comparison with smart phone adoption
		* Sentiment analysis
			* Is sentiment where it should be for the tech to move forward?
			* Excited or disappointed?
			* Predict which product/format will lead the market
			* Who’s leading? Oculus, Sony or HTC?
* Applications
	* Pokemon Go
		* Sentiment

**Computer vision**

* data
	* datasets available from online sources
* Kaggle
	* **Painter by Numbers**
	* Digit Recognizer

**Self-Driving Cars**